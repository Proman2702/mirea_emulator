import datetime

def fibo(n):
    if n <= 1:
        return n
    else:
        return fibo(n-1) + fibo(n-2)

start = datetime.datetime.now()
fibo(40)

finish = datetime.datetime.now()
print('Время работы: ' + str(finish - start))
